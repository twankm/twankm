Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/display_shapes_simpletest.py
    :caption: examples/display_shapes_simpletest.py
    :linenos:

Simple test MagTag
------------------

Simple test with the MagTag.

.. literalinclude:: ../examples/display_shapes_simpletest_magtag.py
    :caption: examples/display_shapes_simpletest_magtag.py
    :linenos:

Sparkline Simple Test
---------------------

Simple test with Sparklines

.. literalinclude:: ../examples/display_shapes_sparkline_simpletest.py
    :caption: examples/display_shapes_sparkline_simpletest.py
    :linenos:

Sparkline Ticks Example
-----------------------

Example using tick with the Sparkline class

.. literalinclude:: ../examples/display_shapes_sparkline_ticks.py
    :caption: examples/display_shapes_sparkline_ticks.py
    :linenos:

Sparkline Triple Test
---------------------

reate background bitmaps and sparklines

.. literalinclude:: ../examples/display_shapes_sparkline_triple.py
    :caption: examples/display_shapes_sparkline_triple.py
    :linenos:

Circle Animation
----------------

Example showing the features of the new Circle setter

.. literalinclude:: ../examples/display_shapes_circle_animation.py
    :caption: examples/display_shapes_circle_animation.py
    :linenos:
