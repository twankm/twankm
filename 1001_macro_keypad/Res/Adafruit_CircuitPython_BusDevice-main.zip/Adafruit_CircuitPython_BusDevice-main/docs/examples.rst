Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/busdevice_read_register_i2c_simpletest.py
    :caption: examples/busdevice_read_register_i2c_simpletest.py
    :linenos:

.. literalinclude:: ../examples/busdevice_read_register_spi_simpletest.py
    :caption: examples/busdevice_read_register_spi_simpletest.py
    :linenos:
