# Suporte

Se você precisa de suporte com o KMK ou quer somente dizer oi, encontre-nos no
canal [no Zulip](https://kmkfw.zulipchat.com).

Se você precisa de ajuda ou pretende abrir um bug report, se
possível se possível, verifique se sua cópia do KMK está atualizada.
