# Ferris Sweep

The [Ferris Sweep](https://github.com/davidphilipbarr/Sweep) is a split, 34 key keyboard designed by David Philip Barr. It uses a Pro-Micro footprint.

It's based in turn on the Ferris by Philip Chevalier.
The default keymap is based on the [original Ferris default keymap](https://github.com/qmk/qmk_firmware/tree/master/keyboards/ferris/keymaps/default).
