# ScottoErgo

![TopShot](https://user-images.githubusercontent.com/8194147/232529199-5df04fe8-fe8d-4419-95fb-40bfbbae3152.jpg)

Please see the [ScottoErgo](https://github.com/joe-scotto/scottokeebs/tree/main/ScottoErgo) GitHub page for details on how and what with to build this board.
