# SPDX-FileCopyrightText: Copyright (c) 2022 JG for Cedar Grove Maker Studios
#
# SPDX-License-Identifier: Unlicense

from cedargrove_leapyear import leap_year

print(leap_year(2000))  # Was a leap year
print(leap_year(2021))  # Was NOT a leap year
