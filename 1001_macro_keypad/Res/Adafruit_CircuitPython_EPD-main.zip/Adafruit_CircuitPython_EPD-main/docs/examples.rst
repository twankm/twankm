Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/epd_simpletest.py
    :caption: examples/epd_simpletest.py
    :linenos:
